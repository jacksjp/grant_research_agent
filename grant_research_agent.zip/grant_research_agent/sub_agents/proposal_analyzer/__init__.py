"""Proposal Analyzer Sub-Agent Package."""
